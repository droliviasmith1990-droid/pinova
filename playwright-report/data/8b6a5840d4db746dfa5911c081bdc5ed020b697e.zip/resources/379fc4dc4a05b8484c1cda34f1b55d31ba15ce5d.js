(globalThis.TURBOPACK || (globalThis.TURBOPACK = [])).push([typeof document === "object" ? document.currentScript : undefined,
"[project]/src/components/canvas/EditorCanvas.tsx [app-client] (ecmascript, next/dynamic entry, async loader)", ((__turbopack_context__) => {

__turbopack_context__.v((parentImport) => {
    return Promise.all([
  "static/chunks/src_00b0faa7._.js",
  "static/chunks/node_modules_0ce1f2dc._.js",
  "static/chunks/src_components_canvas_EditorCanvas_tsx_81c388ee._.js"
].map((chunk) => __turbopack_context__.l(chunk))).then(() => {
        return parentImport("[project]/src/components/canvas/EditorCanvas.tsx [app-client] (ecmascript, next/dynamic entry)");
    });
});
}),
]);