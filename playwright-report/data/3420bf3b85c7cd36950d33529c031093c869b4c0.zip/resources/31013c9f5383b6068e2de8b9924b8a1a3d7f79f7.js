(globalThis.TURBOPACK_CHUNK_LISTS || (globalThis.TURBOPACK_CHUNK_LISTS = [])).push({
    script: typeof document === "object" ? document.currentScript : undefined,
    chunks: [
  "static/chunks/[root-of-the-server]__7a4435ad._.css",
  "static/chunks/node_modules_0b3ebb17._.js",
  "static/chunks/src_b73a57b0._.js"
],
    source: "dynamic"
});
