(globalThis.TURBOPACK_CHUNK_LISTS || (globalThis.TURBOPACK_CHUNK_LISTS = [])).push({
    script: typeof document === "object" ? document.currentScript : undefined,
    chunks: [
  "static/chunks/node_modules_ff23d5d2._.js",
  "static/chunks/src_5a664676._.js"
],
    source: "dynamic"
});
